# Scripts

This skill currently does not require scripts.

Add scripts only when you need deterministic or repetitive execution, for example:

- scoring a prioritization matrix
- generating charts from data
- converting a framework output into PowerPoint-ready tables
- cleaning CSV or Excel inputs
- producing repeatable analysis artifacts

Keep the core consultant reasoning in `SKILL.md` and `references/` unless code is truly needed.
