# Stakeholder map template

Use this for transformation, governance, reorganization, implementation, HR, and change topics.

```markdown
## Stakeholder map
| Stakeholder | Power | Interest | Current stance | Key concern | Desired action | Engagement next step |
|---|---:|---:|---|---|---|---|
|  | High / Med / Low | High / Med / Low | Support / Neutral / Oppose |  |  |  |

## Influence view
| Coalition builders | Potential blockers | Quiet influencers | Must-win stakeholders |
|---|---|---|---|
|  |  |  |  |

## Communication plan
| Audience | Message | Channel | Sender | Timing |
|---|---|---|---|---|
|  |  |  |  |  |

## Stakeholder impact
| Stakeholder | Benefit | Burden / risk | Mitigation |
|---|---|---|---|
|  |  |  |  |
```
