# Issue tree and analysis plan template

Use this when structuring a complex problem.

```markdown
## Core question
<Decision or diagnostic question.>

## Issue tree

1. <Branch 1>
   - <Sub-branch>
   - <Sub-branch>
2. <Branch 2>
   - <Sub-branch>
   - <Sub-branch>
3. <Branch 3>
   - <Sub-branch>
   - <Sub-branch>

## MECE check
| Branch | Potential overlap | Missing coverage | Fix |
|---|---|---|---|
|  |  |  |  |

## Prioritization
| Branch | Likely impact | Controllability | Evidence available | Priority |
|---|---:|---:|---:|---:|
|  |  |  |  |  |

## Hypotheses
| Hypothesis | What would support it | What would refute it | Cheapest next test |
|---|---|---|---|
| H1 |  |  |  |
| H2 |  |  |  |
| H3 |  |  |  |

## Analysis plan
| Analysis | Question answered | Data needed | Owner | Output |
|---|---|---|---|---|
|  |  |  |  |  |

## What we deliberately do not analyze first
- <Low-priority area and why it is deferred.>
```
