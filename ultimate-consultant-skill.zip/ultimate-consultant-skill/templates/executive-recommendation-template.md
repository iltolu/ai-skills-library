# Executive recommendation template

Use this template for leadership-ready answers.

```markdown
## Executive summary
<Direct recommendation in 2–4 sentences. Answer first.>

## Situation
<Neutral context. What is true today?>

## Complication
<What changed, what is difficult, or what creates tension?>

## Core question
<The decision question leaders need to answer.>

## Recommendation
<The recommended choice. Be specific.>

## Why this is the right path
1. <Reason 1>
2. <Reason 2>
3. <Reason 3>

## Options considered
| Option | Upside | Downside | When it works best | Recommendation |
|---|---|---|---|---|
| Option A |  |  |  |  |
| Option B |  |  |  |  |
| Option C |  |  |  |  |

## Risks and mitigations
| Risk | Why it matters | Mitigation | Owner |
|---|---|---|---|
|  |  |  |  |

## Stakeholder impact
| Stakeholder | Likely reaction | Concern | Engagement action |
|---|---|---|---|
|  |  |  |  |

## Next steps
| Step | Owner | Timing | Output |
|---|---|---|---|
| 1 |  |  |  |
| 2 |  |  |  |
| 3 |  |  |  |

## Assumptions and confidence
- Key assumptions:
- Confidence level:
- What could change the recommendation:
- Evidence needed next:
```
