# Implementation plan template

Use this when the user needs to move from recommendation to execution.

```markdown
## Target outcome
<What success looks like.>

## Workstreams
| Workstream | Goal | Key deliverables | Owner |
|---|---|---|---|
|  |  |  |  |

## Governance
| Decision / deliverable | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
|  |  |  |  |  |

## Decision rights
| Decision | Decision owner | Input required from | Escalation trigger |
|---|---|---|---|
|  |  |  |  |

## OKRs
**Objective:** <qualitative outcome>

| Key result | Baseline | Target | Owner |
|---|---:|---:|---|
| KR1 |  |  |  |
| KR2 |  |  |  |
| KR3 |  |  |  |

## 30/60/90-day plan
| Phase | Focus | Actions | Output |
|---|---|---|---|
| 0–30 days | Align and design |  |  |
| 31–60 days | Build and test |  |  |
| 61–90 days | Scale and embed |  |  |

## Change and adoption plan
| Adoption risk | Affected group | Mitigation | Leading indicator |
|---|---|---|---|
|  |  |  |  |

## Risks
| Risk | Probability | Impact | Mitigation | Owner |
|---|---:|---:|---|---|
|  |  |  |  |  |
```
