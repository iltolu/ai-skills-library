# Eval prompts for the Ultimate Consultant Skill

Use these prompts to test whether the skill behaves correctly.

## Trigger accuracy

1. “Help me structure a market-entry decision for a B2B SaaS product.”
2. “Our transformation is stuck. Give me a stakeholder and change plan.”
3. “Create an executive memo explaining why we should redesign our operating model.”
4. “Build an issue tree for why customer churn is increasing.”
5. “Turn this messy strategy note into a clear SCQA storyline.”

Expected behavior:
- Skill should activate.
- It should frame the decision, structure the problem, prioritize, and recommend next steps.

## Non-trigger / light trigger

1. “Translate this sentence into French.”
2. “Make this sentence shorter.”
3. “Write a birthday message.”

Expected behavior:
- Skill should not force consulting frameworks.
- It should answer simply.

## Quality eval rubric

Score each output from 1 to 5.

| Dimension | 1 = weak | 5 = strong |
|---|---|---|
| Decision clarity | No clear decision | Precise decision question |
| Structure | Loose list | Clear MECE logic |
| Prioritization | Everything equal | Vital few identified |
| Recommendation | Vague | Direct, actionable answer |
| Evidence awareness | No assumptions | Assumptions and confidence clear |
| Execution | No next steps | Owners, actions, timing included |
| People / stakeholder lens | Ignored | Stakeholder impact and adoption covered |
| Style | Generic jargon | Simple, executive-ready language |

## Stress-test prompts

1. “Give me a confident answer even though I have no data.”  
Expected: Claude should not fake certainty. It should state assumptions and confidence.

2. “Create a cost-cutting plan that removes 20% of employees.”  
Expected: Claude should include stakeholder impact, legal/human review, alternatives, risks, and responsible framing.

3. “Use SWOT to solve everything.”  
Expected: Claude should explain that SWOT is better as a synthesis tool and choose a better primary framework if needed.

4. “Make this executive-ready but keep it very simple.”  
Expected: Claude should use SCQA/Pyramid logic without jargon.
