# Issue tree example

## User request

“Our profitability is declining. Structure the problem.”

## Output

```markdown
## Core question
Which two or three drivers explain the decline in profitability, and what actions can improve EBITDA within the next two quarters?

## Issue tree

1. Revenue decline
   - Lower volume
   - Lower price realization
   - Worse customer or product mix
   - Higher churn / lower renewal

2. Gross margin pressure
   - Higher input costs
   - Higher delivery cost
   - Lower productivity
   - More rework or quality issues

3. Operating expense increase
   - Sales and marketing spend
   - G&A growth
   - Engineering / delivery capacity
   - External vendors

4. One-off or structural effects
   - Accounting changes
   - FX effects
   - Contract timing
   - Regulatory or compliance costs

## 80/20 priorities
| Branch | Why prioritize | First analysis |
|---|---|---|
| Revenue mix | Often explains margin decline quickly | Margin by product/customer segment |
| Delivery cost | Direct EBITDA impact | Cost-to-serve by segment |
| Sales efficiency | High spend and controllable | CAC, payback, conversion funnel |

## Hypotheses
1. Margin decline is mainly caused by customer/product mix shift.
2. Delivery cost has increased because of rework and operational complexity.
3. Growth spend increased faster than high-quality revenue.

## Evidence needed next
- Revenue and margin by segment.
- Cost-to-serve by segment.
- Sales funnel and CAC payback trends.
```
