# SCQA example

## User request

“Create an executive storyline for why we need to change our promotion process.”

## Output

```markdown
## Situation
The promotion process is an important signal for growth, fairness, and career development. Employees want to understand what is expected and how decisions are made.

## Complication
Today, the process is experienced differently across units. Some employees see a clear path, while others experience uncertainty, high documentation effort, or the perception that relationships matter more than transparent criteria.

## Question
How can we redesign the promotion process so it is fair, transparent, and easier to run, while still protecting quality and business needs?

## Answer
We should move toward a seat-based, transparent, and Workday-supported promotion process. The process should connect business demand, career development, and fair assessment in one clear flow.

## Supporting logic
1. Seat-based planning reduces false expectations.
2. Clear criteria reduce perceived unfairness.
3. Integrated tooling reduces manual effort and improves transparency.
4. A better panel design makes the process less dependent on self-marketing.
```
