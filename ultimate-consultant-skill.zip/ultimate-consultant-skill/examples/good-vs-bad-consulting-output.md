# Good vs bad consulting output

## Bad output

```markdown
We should improve growth by focusing on customers, marketing, and product. The company should align stakeholders and build a roadmap. It is important to create synergies and ensure strong execution.
```

## Why it is weak

- No decision question.
- No prioritization.
- Generic categories overlap.
- No trade-offs.
- No evidence or assumptions.
- No owner, timing, or next step.

## Better output

```markdown
## Recommendation
Focus the next two quarters on activation and retention before increasing acquisition spend.

## Why
1. Acquisition is becoming less efficient: CAC is rising while conversion quality is unclear.
2. Activation is likely the highest-leverage constraint: if new users do not reach value quickly, more acquisition will amplify waste.
3. Retention improvements compound: better onboarding and habit formation can improve NRR and reduce pressure on paid growth.

## What to test first
| Hypothesis | Evidence needed | Cheapest test |
|---|---|---|
| Onboarding is the main churn driver | Cohort activation, time-to-value, first-week drop-off | Analyze last 6 months of cohorts |
| Price is the main churn driver | Win/loss notes, cancellation reasons, competitor pricing | Review top churned accounts |
| Support quality is the main churn driver | Ticket volume, response time, churn correlation | Compare churned vs retained users |

## Assumption
This recommendation assumes churn or weak activation is materially reducing LTV. If activation is healthy and churn is low, the answer may shift back to acquisition or pricing.
```

## Why it is stronger

- Clear recommendation.
- Prioritized logic.
- Competing hypotheses.
- Specific evidence.
- Explicit assumption.
