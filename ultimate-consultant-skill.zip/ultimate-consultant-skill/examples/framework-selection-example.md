# Framework selection example

## User request

“We want to launch an AI product for HR teams. Which framework should we use?”

## Good response

```markdown
Use a combination, not one framework.

## Best framework sequence
1. Problem framing: clarify the decision, target customer, time horizon, and success metric.
2. 3Cs: check fit between your capabilities, HR customer pain points, and competitor gaps.
3. 4Ps: shape the product, pricing, channel, and promotion model.
4. Hypothesis-driven testing: define the riskiest assumptions and test them with customers.
5. SCQA: turn the answer into a clear investor or leadership storyline.

## Why not start with SWOT
SWOT is useful later as a synthesis tool, but it is too generic as the first step. It would produce a list, not a decision.

## First decision question
Which HR customer segment should we target first with an AI leadership-assessment product, and what offer can generate credible early adoption within 90 days?
```
