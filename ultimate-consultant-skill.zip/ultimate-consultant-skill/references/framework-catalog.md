# Framework catalog

This file contains the core frameworks used by the Ultimate Consultant Skill.

Use this as a reference library. Do not apply every framework. Select the smallest useful set for the user's task.

## 1. Problem framing and decision framing

**Definition**  
Translate a vague issue into a precise decision question with objective, scope, constraints, dependencies, stakeholders, and success metric.

**Use when**  
The user asks a broad or vague question such as “What should our strategy be?” or “How do we improve this?”

**Strengths**
- Prevents wasted analysis.
- Improves alignment.
- Makes trade-offs explicit.

**Limitations**
- Can feel slow to impatient users.
- Requires explicit choices and constraints.

**Implementation steps**
1. State the decision-maker.
2. Define the decision to be made.
3. List hard constraints.
4. Name the success metric and time horizon.
5. Identify what would count as a good answer.

**Example**  
Instead of “growth strategy,” frame:  
“Which two growth levers can raise recurring revenue by 15% within four quarters at acceptable CAC?”

**Reusable prompt**  
“Rewrite this problem as a decision question with objective, metric, time horizon, constraints, stakeholders, and decision criteria. Flag missing assumptions before doing analysis.”

---

## 2. MECE

**Definition**  
Group ideas so they are mutually exclusive and collectively exhaustive.

**Use when**  
Creating categories, workstreams, driver trees, slide headlines, analysis buckets, or recommendation groups.

**Strengths**
- Reduces overlap.
- Supports parallel work.
- Improves logic.

**Limitations**
- Perfect MECE is often aspirational.
- Enforcing it too early can suppress creativity.

**Implementation steps**
1. Choose one organizing logic.
2. Test branches for overlap.
3. Test whether a major branch is missing.
4. Relabel branches until the grouping is crisp.

**Example**  
Split revenue growth into price, volume, mix, and expansion rather than overlapping buckets like “sales,” “marketing,” and “customers.”

**Reusable prompt**  
“Organize the answer into MECE buckets. Show where categories overlap, then revise until overlap is minimal and major branches are covered.”

---

## 3. Issue trees and logic trees

**Definition**  
A hierarchical decomposition of a problem into branches that can be analyzed separately.

**Use when**  
Profit decline, churn diagnosis, market-entry decisions, transformation blockers, operating-model issues.

**Strengths**
- Makes ambiguous problems tractable.
- Creates workstreams.
- Reveals where data is needed.

**Limitations**
- Can create false confidence.
- Bad trees encode bad assumptions.

**Implementation steps**
1. Place the core question at the root.
2. Split into top-level branches.
3. Pressure-test MECE.
4. Identify the few branches likely to matter most.
5. Convert branches into analyses.

**Example**  
For declining EBITDA, build branches for revenue, gross margin, SG&A, and working capital, then focus on the largest and most movable drivers.

**Reusable prompt**  
“Build a MECE issue tree for this problem. Label each branch with the evidence needed, the likely owner, and the expected business impact if true.”

---

## 4. Hypothesis-driven problem solving

**Definition**  
Start with candidate explanations or recommendations and test them iteratively instead of collecting data indiscriminately.

**Use when**  
Due diligence, diagnostics under time pressure, strategy work, operational root-cause work, ambiguous growth problems.

**Strengths**
- Fast.
- Efficient.
- Action-oriented.

**Limitations**
- Can create confirmation bias if alternatives are not actively tested.

**Implementation steps**
1. State an initial answer.
2. List observable implications.
3. Specify disconfirming evidence.
4. Run the smallest useful tests first.
5. Revise hypotheses.
6. Keep a “what changed our mind” log.

**Example**  
Hypothesize that churn is driven mainly by onboarding failure rather than price, then test cohort activation, time-to-value, and support tickets before doing full pricing work.

**Reusable prompt**  
“Generate 3 competing hypotheses for the problem, what evidence would support or refute each, and the cheapest next test to discriminate among them.”

---

## 5. 80/20 and Pareto prioritization

**Definition**  
Focus on the vital few drivers likely to account for the largest share of the effect.

**Use when**  
Analysis planning, opportunity sizing, root-cause narrowing, roadmap sequencing, executive prioritization.

**Strengths**
- Accelerates progress.
- Avoids analysis sprawl.
- Helps teams focus.

**Limitations**
- Can hide tail risks.
- Can miss interdependencies or emerging issues.

**Implementation steps**
1. Estimate impact and movability for each branch.
2. Rank by expected value.
3. Select the few high-leverage items.
4. Note what is deliberately deferred.

**Example**  
In pricing, analyze top accounts, top SKUs, and top discount bands before doing full-segment work.

**Reusable prompt**  
“Rank the branches by likely impact and controllability. Recommend the smallest set of analyses that should explain most of the outcome, and list what we are consciously not analyzing first.”

---

## 6. SCQA and Pyramid Principle

**Definition**  
Use Situation, Complication, Question, Answer to frame the audience’s problem, then organize supporting ideas in a pyramid under one main point.

**Use when**  
Executive memo, synthesis slide, client update, recommendation narrative, leadership communication.

**Strengths**
- Clear.
- Persuasive.
- Executive-friendly.

**Limitations**
- Can oversimplify if uncertainty and alternatives are hidden.

**Implementation steps**
1. State the baseline situation.
2. Name the complication.
3. Turn it into the audience’s question.
4. Answer directly.
5. Group support under two to four top-level messages.

**Example**  
Situation: growth slowed.  
Complication: CAC rose faster than ARPU.  
Question: where should we focus first?  
Answer: fix activation, not acquisition, for the next two quarters.

**Reusable prompt**  
“Respond in SCQA form, then build a pyramid with one answer, three supporting messages, and the evidence needed under each message.”

---

## 7. Decision trees and decision analysis

**Definition**  
Map decisions, chance events, payoffs, and probabilities to compare alternatives under uncertainty.

**Use when**  
Market entry, investment choices, make-or-buy, scenario choices, pilot-or-scale choices.

**Strengths**
- Clarifies assumptions.
- Makes uncertainty explicit.
- Supports expected-value comparison.

**Limitations**
- Only as good as the inputs.
- Can become falsely precise.
- May miss qualitative factors if not paired with judgment.

**Implementation steps**
1. Define alternatives.
2. Specify uncertain events.
3. Assign ranges or probabilities.
4. Estimate payoffs.
5. Compare expected values.
6. Run sensitivity analysis.
7. State what variable most changes the answer.

**Example**  
Compare “enter now,” “pilot,” and “wait” using adoption probability, margin, and capex assumptions.

**Reusable prompt**  
“Build a decision tree with options, uncertainties, estimated probabilities, expected values, and the two assumptions to stress-test first.”

---

## 8. 5 Whys

**Definition**  
Repeatedly ask “why” to move beyond symptoms toward underlying causes.

**Use when**  
Process failures, quality issues, incidents, customer-service breakdowns, recurring operational problems.

**Strengths**
- Simple.
- Fast.
- Accessible to broad teams.

**Limitations**
- Can be too linear.
- Can stop too early.
- Can collapse complex systems into one cause.

**Implementation steps**
1. Define the problem precisely.
2. Ask why iteratively.
3. Verify each answer with evidence.
4. Branch if multiple causes emerge.
5. Stop only at a cause that can be acted on.

**Example**  
“Orders ship late” may trace to forecast error, data latency, replenishment policy, or warehouse process.

**Reusable prompt**  
“Run a 5 Whys analysis, but allow branching if more than one plausible cause exists. For each why, state the evidence confidence and what observation would falsify it.”

---

## 9. Porter’s Five Forces

**Definition**  
Analyze rivalry, threat of entrants, supplier power, buyer power, and substitutes to understand industry structure and profit potential.

**Use when**  
Market entry, category attractiveness, pricing power, strategic positioning.

**Strengths**
- Strong external-structure lens.
- Useful for industry economics.

**Limitations**
- Weaker for internal capabilities.
- Less useful for blurred ecosystem boundaries unless paired with other tools.

**Implementation steps**
1. Define the industry carefully.
2. Assess each force.
3. Identify which forces most depress or protect profit.
4. Note trends changing the forces.
5. Translate into strategic options.

**Example**  
Assess a B2B SaaS category by buyer switching costs, substitute workflows, and entrant barriers from data or network effects.

**Reusable prompt**  
“Apply Five Forces to this industry. Identify the two forces that most constrain profitability, the trend likely to shift them, and the implications for market entry or positioning.”

---

## 10. Value chain

**Definition**  
Disaggregate a business into strategically relevant activities to find sources of cost advantage or differentiation.

**Use when**  
Profit improvement, operating-model review, make-or-buy, service redesign, AI automation targeting.

**Strengths**
- Bridges strategy and operations.
- Highly actionable.

**Limitations**
- Can understate ecosystem, platform, or cross-firm effects if used too narrowly.

**Implementation steps**
1. Map primary and support activities.
2. Estimate cost and value contribution.
3. Locate bottlenecks and differentiators.
4. Translate into redesign actions.

**Example**  
In e-commerce, compare merchandising, digital acquisition, fulfillment, returns, and service as sources of margin erosion or differentiation.

**Reusable prompt**  
“Map the value chain for this business, identify the three activities most likely to drive cost or differentiation, and recommend what to redesign first.”

---

## 11. 3Cs

**Definition**  
Analyze Corporation, Customers, and Competitors as the core strategic triangle.

**Use when**  
Growth strategy, positioning, GTM simplification, strategic storyline.

**Strengths**
- Fast.
- Intuitive.
- Low data burden.

**Limitations**
- Lighter than Five Forces for industry economics.
- Lighter than value-chain work for operations.

**Implementation steps**
1. Summarize company capabilities and constraints.
2. Define high-value customer needs and segments.
3. Compare competitor positions.
4. Identify where the three align to create advantage.

**Example**  
Choose whether to pursue mid-market customers by testing fit between company capabilities, customer pain points, and weak incumbent offerings.

**Reusable prompt**  
“Analyze this problem through the 3Cs: what matters about the company, the customers, and the competitors, and where is the most attractive strategic fit?”

---

## 12. 4Ps

**Definition**  
A marketing-mix lens: Product, Price, Place, Promotion.

**Use when**  
Launch planning, commercialization, demand generation, growth diagnostics.

**Strengths**
- Practical.
- Actionable for marketing choices.

**Limitations**
- Product-centric.
- Less useful for broad corporate strategy or non-market operating issues.

**Implementation steps**
1. Define the value proposition.
2. Define pricing logic.
3. Define channel or distribution approach.
4. Define promotion strategy.
5. Check consistency across all four levers.

**Example**  
A software bundle may need product simplification, usage-based pricing, partner distribution, and proof-point-led promotion.

**Reusable prompt**  
“Use the 4Ps to assess this offer. For each P, identify the current choice, the likely weakness, and the highest-value change.”

---

## 13. SWOT and TOWS

**Definition**  
SWOT inventories strengths, weaknesses, opportunities, and threats. TOWS matches those factors into strategy options.

**Use when**  
Synthesis after deeper analysis, planning workshops, option generation.

**Strengths**
- Broad.
- Accessible.
- Useful workshop bridge.

**Limitations**
- SWOT alone often stays generic.
- TOWS is usually more useful because it generates options.

**Implementation steps**
1. Complete SWOT only after substantive analysis.
2. Generate SO, ST, WO, and WT strategies.
3. Rank options by feasibility and business impact.

**Example**  
After Five Forces and value-chain work, use TOWS to turn findings into offensive and defensive moves.

**Reusable prompt**  
“Create a SWOT from the evidence already gathered, then convert it into a TOWS matrix with SO, ST, WO, and WT options ranked by business impact and ease of execution.”

---

## 14. Stakeholder mapping

**Definition**  
Identify who matters, what they care about, how much influence they have, and whether they support, oppose, or are neutral toward an initiative.

**Use when**  
Transformations, operating-model changes, market entry with regulators, reorgs, cross-functional launches.

**Strengths**
- Reduces political surprises.
- Improves buy-in and communication sequencing.

**Limitations**
- Maps age quickly.
- Organizational politics can make the map sensitive.

**Implementation steps**
1. List stakeholders.
2. Assess power, interest, stance, and concerns.
3. Map each against key initiatives.
4. Design tailored engagement actions.

**Example**  
For an ERP rollout, map sponsors, regional leaders, finance controllers, frontline users, IT architects, and works councils.

**Reusable prompt**  
“Create a stakeholder map with role, power, likely stance, key concern, desired action, and next engagement step. Flag likely blockers and coalition builders.”

---

## 15. RACI, RAPID, and OVIS-style decision rights

**Definition**  
RACI clarifies who is Responsible, Accountable, Consulted, and Informed. RAPID-style and OVIS-style models focus more directly on decision rights.

**Use when**  
Implementation governance, transformation offices, cross-functional operating rhythm, escalation paths.

**Strengths**
- Cuts role ambiguity.
- Speeds execution.
- Clarifies accountability.

**Limitations**
- RACI is weaker for contested strategic decisions.
- Decision-rights variants take more design effort.

**Implementation steps**
1. Identify critical decisions or deliverables.
2. Assign ownership.
3. Ensure one clear accountable owner.
4. Identify required input voices.
5. Review bottlenecks after initial use.

**Example**  
For pricing governance, one leader owns decision accountability, finance gives input, sales is consulted, and channels are informed.

**Reusable prompt**  
“Build a RACI for this initiative. If the challenge is decision bottlenecks rather than task confusion, convert it into a decision-rights map closer to RAPID-style roles.”

---

## 16. OKRs

**Definition**  
A goal-setting framework with qualitative objectives and measurable key results.

**Use when**  
Strategy deployment, quarterly priorities, transformation tracking, initiative-level accountability.

**Strengths**
- Aligns teams around outcomes.
- Connects strategy to measurable progress.

**Limitations**
- Weak OKRs become KPIs or to-do lists.
- Bad cascades become bureaucratic.

**Implementation steps**
1. Define one clear objective.
2. Set three to five outcome-based key results.
3. Link team OKRs to enterprise priorities.
4. Review and score on a regular cadence.

**Example**  
Objective: restore growth quality.  
Key results: raise activation to X, reduce CAC payback to Y, lift NRR to Z.

**Reusable prompt**  
“Translate this strategy into OKRs. Write one objective and three to five outcome-based key results, then note what initiatives would most likely move those results.”

---

## 17. McKinsey 7-S

**Definition**  
Analyze organizational effectiveness through seven interdependent elements: shared values, strategy, structure, systems, style, skills, and staff.

**Use when**  
Organization design, post-merger integration, operating-model changes, capability transformation.

**Strengths**
- Holistic.
- Good for diagnosing misalignment.

**Limitations**
- Broad rather than sharply causal.
- Needs concrete evidence to avoid generic output.

**Implementation steps**
1. Assess each S.
2. Identify inconsistencies.
3. Trace which misalignments most constrain performance.
4. Sequence interventions instead of changing everything at once.

**Example**  
A product company may have a sound strategy but misaligned incentives, weak product-management skills, and legacy governance systems.

**Reusable prompt**  
“Run a 7-S diagnosis. Which Ss are aligned, which are not, and which two misalignments most likely explain the performance gap?”

---

## 18. Change models: Kotter, ADKAR, and influence-model lens

**Definition**  
Different change models solve different parts of the change problem.

- Kotter: mobilization, urgency, coalition, vision, barrier removal, short-term wins.
- ADKAR: individual adoption through awareness, desire, knowledge, ability, reinforcement.
- Influence-model lens: behavior change through conviction, role modeling, formal mechanisms, and talent/skills.

**Use when**  
Complex transformations, ERP or AI rollouts, reorgs, cultural shifts, behavior change.

**Strengths**
- Kotter is strong for mobilization.
- ADKAR is strong for adoption risks.
- Influence-model thinking is strong for sustained behavior change.

**Limitations**
- No model is universal.
- Over-standardizing change can ignore local context.

**Implementation steps**
1. Use Kotter to mobilize.
2. Use ADKAR to assess person-by-person adoption gaps.
3. Use influence-model mechanisms to embed new behaviors.
4. Add governance, communication, reinforcement, and leading indicators.

**Example**  
For an AI rollout, use urgency and coalition to launch, ADKAR to diagnose manager resistance, and formal mechanisms plus role modeling to change actual usage.

**Reusable prompt**  
“Design a change plan using Kotter for mobilization, ADKAR for adoption risks, and an influence-model view for behavior reinforcement. Show actions by phase, owner, and leading indicator.”
