# Framework selection map

Use this file when choosing which consulting framework to apply.

## Comparison by purpose, complexity, and data needs

| Framework | Primary purpose | Complexity | Data needs | Typical output | Typical users |
|---|---|---:|---:|---|---|
| Problem framing | Clarify the decision | Low | Low | Decision statement | All consultants |
| MECE | Structure categories cleanly | Low | Low | Buckets / workstreams | All consultants |
| Issue tree | Decompose the problem | Medium | Low–medium | Tree / analysis plan | Strategy, operations |
| Hypothesis-driven | Focus testing | Medium | Medium | Test plan / evidence log | Strategy, diligence |
| 80/20 | Prioritize effort | Low | Low–medium | Ranked priorities | All consultants |
| SCQA / Pyramid | Communicate the answer | Medium | Low | Memo / storyline | Managers, partners |
| Decision tree | Compare choices under uncertainty | Medium–high | Medium–high | Scenario tree / expected value | Strategy, finance |
| 5 Whys | Diagnose root causes | Low | Low | Causal chain | Ops, quality, transformation |
| Five Forces | Assess industry attractiveness | Medium | Medium | Industry structure assessment | Strategy |
| Value chain | Find cost or differentiation levers | Medium | Medium–high | Activity map / redesign options | Strategy, operations |
| 3Cs | Build fast strategic view | Low | Low–medium | Fit assessment | Strategy, growth |
| 4Ps | Shape commercialization | Medium | Medium | Marketing action plan | Growth, marketing |
| SWOT / TOWS | Synthesize and generate options | Low–medium | Low–medium | Option matrix | Workshops, strategy |
| Stakeholder map | Manage buy-in and politics | Medium | Medium | Influence map | Transformation, PMO |
| RACI | Clarify roles | Low | Low | Responsibility matrix | PMO, implementation |
| OKR | Deploy strategy into measurable goals | Medium | Medium | Goal system | Leadership, PMO |
| 7-S | Diagnose organizational alignment | Medium | Medium | Alignment diagnosis | Org design, transformation |
| Change models | Mobilize and embed change | Medium–high | Medium | Phased change plan | Transformation leaders |

## Mapping to common consulting tasks

| Consulting task | Primary frameworks | Secondary frameworks |
|---|---|---|
| Problem structuring | Problem framing, MECE, issue tree, hypothesis-driven | 80/20, 3Cs |
| Analysis | Decision tree, Five Forces, value chain, 5 Whys | 4Ps, SWOT/TOWS |
| Communication | SCQA / Pyramid Principle | MECE, issue tree |
| Decision-making | Decision tree, decision rights, 80/20 | Five Forces, 7-S |
| Implementation | Stakeholder map, RACI, OKR, change models | 7-S, value chain |

## Recommended skill flow

```mermaid
flowchart TD
    A[Intake and context] --> B[Frame the decision]
    B --> C[Build MECE issue tree]
    C --> D[Apply 80/20 prioritization]
    D --> E[Generate competing hypotheses]
    E --> F{Problem type}
    F -->|Industry / strategy| G[Five Forces and 3Cs]
    F -->|Growth / GTM| H[4Ps and customer questions]
    F -->|Operations / cost| I[Value chain and 5 Whys]
    F -->|Uncertainty / options| J[Decision tree]
    F -->|Organization / transformation| Q[7-S and stakeholder map]
    G --> K[SWOT or TOWS synthesis]
    H --> K
    I --> K
    J --> K
    Q --> K
    K --> L[SCQA recommendation]
    L --> M[Stakeholder map]
    M --> N[RACI or decision-rights map]
    N --> O[OKRs and change plan]
    O --> P[Review uncertainty, risks, and stakeholder impact]
```

## Common framework combinations

### Strategy and market entry

Use:

1. Problem framing
2. MECE issue tree
3. Hypothesis-driven testing
4. Five Forces
5. 3Cs
6. SCQA recommendation

Best output:
- Market-entry recommendation
- Strategic option comparison
- Risks and trigger points

### Operations and margin improvement

Use:

1. Problem framing
2. Profit or value-chain issue tree
3. 80/20 prioritization
4. 5 Whys on biggest pain points
5. Value-chain redesign
6. SCQA recommendation

Best output:
- Cost or margin driver tree
- Prioritized improvement levers
- 30/60/90-day action plan

### Growth and go-to-market

Use:

1. Problem framing
2. 3Cs
3. 4Ps
4. Customer or segment analysis
5. Hypothesis tests
6. SCQA recommendation

Best output:
- Growth lever prioritization
- GTM action plan
- Test-and-learn roadmap

### Implementation-heavy transformation

Use:

1. SCQA to state the case for change
2. Stakeholder mapping
3. RACI or decision-rights map
4. OKRs
5. 7-S alignment check
6. Change models

Best output:
- Governance model
- Adoption plan
- Stakeholder and communication plan
- Leading indicators

### Ambiguous executive request

Use:

1. Problem framing
2. MECE buckets
3. 80/20 prioritization
4. SCQA answer

Best output:
- Short executive answer
- Decision question
- Key assumptions
- Next steps

## Framework choice rules

- If the user asks “what should we do?” start with problem framing and SCQA.
- If the user asks “why is this happening?” use issue tree and 5 Whys.
- If the user asks “which option is best?” use decision tree or option matrix.
- If the user asks “how do we implement?” use stakeholder map, RACI, OKRs, and change model.
- If the user asks “how do we communicate this?” use SCQA and Pyramid Principle.
- If the user asks “is this market attractive?” use Five Forces and 3Cs.
- If the user asks “how do we grow?” use 3Cs, 4Ps, and growth driver tree.
- If the user asks “how do we reduce cost or improve margin?” use value chain and 80/20.

## Anti-patterns

Avoid these mistakes:

- Applying every framework because it exists.
- Using SWOT as a first analysis instead of a synthesis tool.
- Creating an issue tree without naming the decision question.
- Producing a recommendation without assumptions and risks.
- Producing implementation plans without ownership.
- Treating stakeholder management as a communication afterthought.
- Using precise numbers when inputs are guesses.
